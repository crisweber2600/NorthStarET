namespace NorthStar.EF6.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class iskdg : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.AssessmentFieldGroup", "IsKdg", c => c.Boolean(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.AssessmentFieldGroup", "IsKdg");
        }
    }
}

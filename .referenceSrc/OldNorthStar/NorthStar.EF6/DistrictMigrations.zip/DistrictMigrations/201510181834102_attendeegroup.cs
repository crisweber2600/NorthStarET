namespace NorthStar.EF6.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class attendeegroup : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.AttendeeGroup",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        GroupName = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.AttendeeGroupStaff",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        StaffId = c.Int(nullable: false),
                        AttendeeGroupId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.AttendeeGroup", t => t.AttendeeGroupId, cascadeDelete: true)
                .ForeignKey("dbo.Staff", t => t.StaffId, cascadeDelete: true)
                .Index(t => t.StaffId)
                .Index(t => t.AttendeeGroupId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.AttendeeGroupStaff", "StaffId", "dbo.Staff");
            DropForeignKey("dbo.AttendeeGroupStaff", "AttendeeGroupId", "dbo.AttendeeGroup");
            DropIndex("dbo.AttendeeGroupStaff", new[] { "AttendeeGroupId" });
            DropIndex("dbo.AttendeeGroupStaff", new[] { "StaffId" });
            DropTable("dbo.AttendeeGroupStaff");
            DropTable("dbo.AttendeeGroup");
        }
    }
}

namespace NorthStar.EF6.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class new2 : DbMigration
    {
        public override void Up()
        {
            //CreateTable(
            //    "dbo.InterventionCardinality",
            //    c => new
            //        {
            //            Id = c.Int(nullable: false, identity: true),
            //            CardinalityName = c.String(),
            //        })
            //    .PrimaryKey(t => t.Id);
            
            //CreateTable(
            //    "dbo.Intervention",
            //    c => new
            //        {
            //            Id = c.Int(nullable: false, identity: true),
            //            InterventionType = c.String(),
            //            bDisplay = c.Boolean(nullable: false),
            //            Description = c.String(),
            //            DefaultTextLevelType = c.Int(),
            //            InterventionCardinalityID = c.Int(),
            //            ExitCriteria = c.String(),
            //            EntranceCriteria = c.String(),
            //            LearnerNeed = c.String(),
            //            DetailedDescription = c.String(),
            //            TimeOfYear = c.String(),
            //            InterventionTierID = c.Int(),
            //            CategoryID = c.Int(),
            //            BriefDescription = c.String(),
            //            FrameworkID = c.Int(),
            //            UnitOfStudyID = c.Int(),
            //            WorkshopID = c.Int(),
            //            ModifiedDate = c.DateTime(),
            //            Ip = c.String(),
            //            ModifiedBy = c.String(),
            //            InterventionCategory_Id = c.Int(),
            //            InterventionFramework_Id = c.Int(),
            //            InterventionUnitOfStudy_Id = c.Int(),
            //            InterventionWorkshop_Id = c.Int(),
            //        })
            //    .PrimaryKey(t => t.Id)
            //    .ForeignKey("dbo.InterventionCardinality", t => t.InterventionCardinalityID)
            //    .ForeignKey("dbo.InterventionCategory", t => t.InterventionCategory_Id)
            //    .ForeignKey("dbo.InterventionFramework", t => t.InterventionFramework_Id)
            //    .ForeignKey("dbo.InterventionTier", t => t.InterventionTierID)
            //    .ForeignKey("dbo.InterventionUnitOfStudy", t => t.InterventionUnitOfStudy_Id)
            //    .ForeignKey("dbo.InterventionWorkshop", t => t.InterventionWorkshop_Id)
            //    .Index(t => t.InterventionCardinalityID)
            //    .Index(t => t.InterventionTierID)
            //    .Index(t => t.InterventionCategory_Id)
            //    .Index(t => t.InterventionFramework_Id)
            //    .Index(t => t.InterventionUnitOfStudy_Id)
            //    .Index(t => t.InterventionWorkshop_Id);
            
            //CreateTable(
            //    "dbo.InterventionCategory",
            //    c => new
            //        {
            //            Id = c.Int(nullable: false, identity: true),
            //            CategoryName = c.String(),
            //            CategoryDescription = c.String(),
            //            SortOrder = c.Int(),
            //        })
            //    .PrimaryKey(t => t.Id);
            
            //CreateTable(
            //    "dbo.InterventionFramework",
            //    c => new
            //        {
            //            Id = c.Int(nullable: false, identity: true),
            //            FrameworkName = c.String(),
            //            FreameworkDescription = c.String(),
            //        })
            //    .PrimaryKey(t => t.Id);
            
            //CreateTable(
            //    "dbo.InterventionGrade",
            //    c => new
            //        {
            //            Id = c.Int(nullable: false, identity: true),
            //            InterventionID = c.Int(nullable: false),
            //            GradeID = c.Int(nullable: false),
            //        })
            //    .PrimaryKey(t => t.Id)
            //    .ForeignKey("dbo.Grade", t => t.GradeID, cascadeDelete: true)
            //    .ForeignKey("dbo.Intervention", t => t.InterventionID, cascadeDelete: true)
            //    .Index(t => t.InterventionID)
            //    .Index(t => t.GradeID);
            
            //CreateTable(
            //    "dbo.InterventionToolIntervention",
            //    c => new
            //        {
            //            Id = c.Int(nullable: false, identity: true),
            //            InterventionID = c.Int(nullable: false),
            //            InterventionToolID = c.Int(nullable: false),
            //            SortOrder = c.Int(),
            //        })
            //    .PrimaryKey(t => t.Id)
            //    .ForeignKey("dbo.InterventionTool", t => t.InterventionToolID, cascadeDelete: true)
            //    .ForeignKey("dbo.Intervention", t => t.InterventionID, cascadeDelete: true)
            //    .Index(t => t.InterventionID)
            //    .Index(t => t.InterventionToolID);
            
            //CreateTable(
            //    "dbo.InterventionTool",
            //    c => new
            //        {
            //            Id = c.Int(nullable: false, identity: true),
            //            ToolName = c.String(),
            //            ToolFileName = c.String(),
            //            Description = c.String(),
            //            SortOrder = c.Int(),
            //            FileSystemFileName = c.String(),
            //            LastModified = c.DateTime(),
            //            FileSize = c.Int(),
            //            FileExtension = c.String(),
            //            ToolTypeID = c.Int(),
            //            InterventionToolType_Id = c.Int(),
            //        })
            //    .PrimaryKey(t => t.Id)
            //    .ForeignKey("dbo.InterventionToolType", t => t.InterventionToolType_Id)
            //    .Index(t => t.InterventionToolType_Id);
            
            //CreateTable(
            //    "dbo.InterventionToolType",
            //    c => new
            //        {
            //            Id = c.Int(nullable: false, identity: true),
            //            Name = c.String(),
            //        })
            //    .PrimaryKey(t => t.Id);
            
            //CreateTable(
            //    "dbo.InterventionUnitOfStudy",
            //    c => new
            //        {
            //            Id = c.Int(nullable: false, identity: true),
            //            UnitName = c.String(),
            //            UnitDescription = c.String(),
            //        })
            //    .PrimaryKey(t => t.Id);
            
            //CreateTable(
            //    "dbo.InterventionWorkshop",
            //    c => new
            //        {
            //            Id = c.Int(nullable: false, identity: true),
            //            WorkshopName = c.String(),
            //            WorkshopDescription = c.String(),
            //        })
            //    .PrimaryKey(t => t.Id);
            
            //CreateTable(
            //    "dbo.AssessmentLookupField",
            //    c => new
            //        {
            //            Id = c.Int(nullable: false, identity: true),
            //            FieldName = c.String(),
            //            FieldValue = c.String(),
            //            SortOrder = c.Int(nullable: false),
            //            FieldSpecificId = c.Int(),
            //            Description = c.String(),
            //            ModifiedDate = c.DateTime(),
            //            Ip = c.String(),
            //            ModifiedBy = c.String(),
            //        })
            //    .PrimaryKey(t => t.Id);
            
            //CreateTable(
            //    "dbo.TestDueDate",
            //    c => new
            //        {
            //            Id = c.Int(nullable: false, identity: true),
            //            SchoolStartYear = c.Int(),
            //            DueDate = c.DateTime(),
            //            TestLevelPeriodID = c.Int(),
            //            Notes = c.String(),
            //            Hex = c.String(),
            //            IsSupplemental = c.Boolean(),
            //            StartDate = c.DateTime(),
            //            EndDate = c.DateTime(),
            //            ModifiedDate = c.DateTime(),
            //            Ip = c.String(),
            //            ModifiedBy = c.String(),
            //        })
            //    .PrimaryKey(t => t.Id);
            
            //AddColumn("dbo.Section", "Intervention_Id", c => c.Int());
            //CreateIndex("dbo.Section", "Intervention_Id");
            //AddForeignKey("dbo.Section", "Intervention_Id", "dbo.Intervention", "Id");
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Section", "Intervention_Id", "dbo.Intervention");
            DropForeignKey("dbo.Intervention", "InterventionWorkshop_Id", "dbo.InterventionWorkshop");
            DropForeignKey("dbo.Intervention", "InterventionUnitOfStudy_Id", "dbo.InterventionUnitOfStudy");
            DropForeignKey("dbo.InterventionToolIntervention", "InterventionID", "dbo.Intervention");
            DropForeignKey("dbo.InterventionTool", "InterventionToolType_Id", "dbo.InterventionToolType");
            DropForeignKey("dbo.InterventionToolIntervention", "InterventionToolID", "dbo.InterventionTool");
            DropForeignKey("dbo.Intervention", "InterventionTierID", "dbo.InterventionTier");
            DropForeignKey("dbo.InterventionGrade", "InterventionID", "dbo.Intervention");
            DropForeignKey("dbo.InterventionGrade", "GradeID", "dbo.Grade");
            DropForeignKey("dbo.Intervention", "InterventionFramework_Id", "dbo.InterventionFramework");
            DropForeignKey("dbo.Intervention", "InterventionCategory_Id", "dbo.InterventionCategory");
            DropForeignKey("dbo.Intervention", "InterventionCardinalityID", "dbo.InterventionCardinality");
            DropIndex("dbo.Section", new[] { "Intervention_Id" });
            DropIndex("dbo.InterventionTool", new[] { "InterventionToolType_Id" });
            DropIndex("dbo.InterventionToolIntervention", new[] { "InterventionToolID" });
            DropIndex("dbo.InterventionToolIntervention", new[] { "InterventionID" });
            DropIndex("dbo.InterventionGrade", new[] { "GradeID" });
            DropIndex("dbo.InterventionGrade", new[] { "InterventionID" });
            DropIndex("dbo.Intervention", new[] { "InterventionWorkshop_Id" });
            DropIndex("dbo.Intervention", new[] { "InterventionUnitOfStudy_Id" });
            DropIndex("dbo.Intervention", new[] { "InterventionFramework_Id" });
            DropIndex("dbo.Intervention", new[] { "InterventionCategory_Id" });
            DropIndex("dbo.Intervention", new[] { "InterventionTierID" });
            DropIndex("dbo.Intervention", new[] { "InterventionCardinalityID" });
            DropColumn("dbo.Section", "Intervention_Id");
            DropTable("dbo.TestDueDate");
            DropTable("dbo.AssessmentLookupField");
            DropTable("dbo.InterventionWorkshop");
            DropTable("dbo.InterventionUnitOfStudy");
            DropTable("dbo.InterventionToolType");
            DropTable("dbo.InterventionTool");
            DropTable("dbo.InterventionToolIntervention");
            DropTable("dbo.InterventionGrade");
            DropTable("dbo.InterventionFramework");
            DropTable("dbo.InterventionCategory");
            DropTable("dbo.Intervention");
            DropTable("dbo.InterventionCardinality");
        }
    }
}

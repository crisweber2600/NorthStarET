namespace NorthStar.EF6.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class studentattrs3 : DbMigration
    {
        public override void Up()
        {
            //DropColumn("dbo.StudentAttributeData", "StudentID");
            //RenameColumn(table: "dbo.StudentAttributeData", name: "AttributeID", newName: "StudentID");
            //RenameIndex(table: "dbo.StudentAttributeData", name: "IX_AttributeID", newName: "IX_StudentID");
            //CreateIndex("dbo.StudentAttributeData", "AttributeID");
        }
        
        public override void Down()
        {
            //DropIndex("dbo.StudentAttributeData", new[] { "AttributeID" });
            //RenameIndex(table: "dbo.StudentAttributeData", name: "IX_StudentID", newName: "IX_AttributeID");
            //RenameColumn(table: "dbo.StudentAttributeData", name: "StudentID", newName: "AttributeID");
            //AddColumn("dbo.StudentAttributeData", "StudentID", c => c.Int(nullable: false));
        }
    }
}

namespace NorthStar.EF6.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class interventionattendancerecorder : DbMigration
    {
        public override void Up()
        {
            CreateIndex("dbo.InterventionAttendance", "RecorderID");
            AddForeignKey("dbo.InterventionAttendance", "RecorderID", "dbo.Staff", "Id");
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.InterventionAttendance", "RecorderID", "dbo.Staff");
            DropIndex("dbo.InterventionAttendance", new[] { "RecorderID" });
        }
    }
}

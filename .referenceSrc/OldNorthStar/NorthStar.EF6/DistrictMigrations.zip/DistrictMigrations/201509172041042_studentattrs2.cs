namespace NorthStar.EF6.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class studentattrs2 : DbMigration
    {
        public override void Up()
        {
            //DropColumn("dbo.StudentAttributeData", "AttributeValueID");
            //RenameColumn(table: "dbo.StudentAttributeData", name: "Value_Id", newName: "AttributeValueID");
            //RenameIndex(table: "dbo.StudentAttributeData", name: "IX_Value_Id", newName: "IX_AttributeValueID");
        }
        
        public override void Down()
        {
            //RenameIndex(table: "dbo.StudentAttributeData", name: "IX_AttributeValueID", newName: "IX_Value_Id");
            //RenameColumn(table: "dbo.StudentAttributeData", name: "AttributeValueID", newName: "Value_Id");
            //AddColumn("dbo.StudentAttributeData", "AttributeValueID", c => c.Int(nullable: false));
        }
    }
}

namespace NorthStar.EF6.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class benchmarks2 : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.TestLevelPeriod",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Title = c.String(),
                        PeriodOrder = c.Int(nullable: false),
                        Notes = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateIndex("dbo.Assessment_Benchmarks", "GradeID");
            CreateIndex("dbo.Assessment_Benchmarks", "TestLevelPeriodID");
            AddForeignKey("dbo.Assessment_Benchmarks", "GradeID", "dbo.Grade", "Id");
            AddForeignKey("dbo.Assessment_Benchmarks", "TestLevelPeriodID", "dbo.TestLevelPeriod", "Id");
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Assessment_Benchmarks", "TestLevelPeriodID", "dbo.TestLevelPeriod");
            DropForeignKey("dbo.Assessment_Benchmarks", "GradeID", "dbo.Grade");
            DropIndex("dbo.Assessment_Benchmarks", new[] { "TestLevelPeriodID" });
            DropIndex("dbo.Assessment_Benchmarks", new[] { "GradeID" });
            DropTable("dbo.TestLevelPeriod");
        }
    }
}

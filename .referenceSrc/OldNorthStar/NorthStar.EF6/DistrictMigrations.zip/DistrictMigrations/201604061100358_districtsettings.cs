namespace NorthStar.EF6.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class districtsettings : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.StaffSetting",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        StaffId = c.Int(nullable: false),
                        SelectedValueId = c.Int(nullable: false),
                        Attribute = c.String(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Staff", t => t.StaffId, cascadeDelete: true)
                .Index(t => t.StaffId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.StaffSetting", "StaffId", "dbo.Staff");
            DropIndex("dbo.StaffSetting", new[] { "StaffId" });
            DropTable("dbo.StaffSetting");
        }
    }
}

namespace NorthStar.EF6.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class new3 : DbMigration
    {
        public override void Up()
        {
            //RenameTable(name: "dbo.Intervention", newName: "InterventionType");
        }
        
        public override void Down()
        {
            RenameTable(name: "dbo.InterventionType", newName: "Intervention");
        }
    }
}

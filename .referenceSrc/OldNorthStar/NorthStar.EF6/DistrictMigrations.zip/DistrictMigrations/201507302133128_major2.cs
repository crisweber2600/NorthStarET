namespace NorthStar.EF6.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class major2 : DbMigration
    {
        public override void Up()
        {
            //DropColumn("dbo.Section", "InterventionTypeID");
            //RenameColumn(table: "dbo.Section", name: "Intervention_Id", newName: "InterventionTypeID");
            //RenameIndex(table: "dbo.Section", name: "IX_Intervention_Id", newName: "IX_InterventionTypeID");
        }
        
        public override void Down()
        {
            RenameIndex(table: "dbo.Section", name: "IX_InterventionTypeID", newName: "IX_Intervention_Id");
            RenameColumn(table: "dbo.Section", name: "InterventionTypeID", newName: "Intervention_Id");
            AddColumn("dbo.Section", "InterventionTypeID", c => c.Int());
        }
    }
}

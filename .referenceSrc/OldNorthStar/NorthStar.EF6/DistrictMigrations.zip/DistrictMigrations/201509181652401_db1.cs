namespace NorthStar.EF6.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class db1 : DbMigration
    {
        public override void Up()
        {
            //CreateIndex("dbo.StudentSchool", "SchoolStartYear");
            //AddForeignKey("dbo.StudentSchool", "SchoolStartYear", "dbo.SchoolYear", "SchoolStartYear", cascadeDelete: true);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.StudentSchool", "SchoolStartYear", "dbo.SchoolYear");
            DropIndex("dbo.StudentSchool", new[] { "SchoolStartYear" });
        }
    }
}

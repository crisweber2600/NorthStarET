namespace NorthStar.EF6.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class staffschoolgrade2 : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.StaffSchoolGrade", "Grade_Id", "dbo.Grade");
            DropIndex("dbo.StaffSchoolGrade", new[] { "Grade_Id" });
            RenameColumn(table: "dbo.StaffSchoolGrade", name: "Grade_Id", newName: "GradeID");
            AlterColumn("dbo.StaffSchoolGrade", "GradeID", c => c.Int(nullable: false));
            CreateIndex("dbo.StaffSchoolGrade", "GradeID");
            AddForeignKey("dbo.StaffSchoolGrade", "GradeID", "dbo.Grade", "Id", cascadeDelete: true);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.StaffSchoolGrade", "GradeID", "dbo.Grade");
            DropIndex("dbo.StaffSchoolGrade", new[] { "GradeID" });
            AlterColumn("dbo.StaffSchoolGrade", "GradeID", c => c.Int());
            RenameColumn(table: "dbo.StaffSchoolGrade", name: "GradeID", newName: "Grade_Id");
            CreateIndex("dbo.StaffSchoolGrade", "Grade_Id");
            AddForeignKey("dbo.StaffSchoolGrade", "Grade_Id", "dbo.Grade", "Id");
        }
    }
}

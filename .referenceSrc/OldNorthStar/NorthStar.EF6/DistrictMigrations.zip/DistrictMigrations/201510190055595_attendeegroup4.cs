namespace NorthStar.EF6.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class attendeegroup4 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.AttendeeGroup", "StaffId", c => c.Int(nullable: false));
            CreateIndex("dbo.AttendeeGroup", "StaffId");
            AddForeignKey("dbo.AttendeeGroup", "StaffId", "dbo.Staff", "Id");
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.AttendeeGroup", "StaffId", "dbo.Staff");
            DropIndex("dbo.AttendeeGroup", new[] { "StaffId" });
            DropColumn("dbo.AttendeeGroup", "StaffId");
        }
    }
}

namespace NorthStar.EF6.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class attendancreason : DbMigration
    {
        public override void Up()
        {
            CreateIndex("dbo.InterventionAttendance", "AttendanceReasonID");
            AddForeignKey("dbo.InterventionAttendance", "AttendanceReasonID", "dbo.AttendanceReason", "Id", cascadeDelete: true);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.InterventionAttendance", "AttendanceReasonID", "dbo.AttendanceReason");
            DropIndex("dbo.InterventionAttendance", new[] { "AttendanceReasonID" });
        }
    }
}

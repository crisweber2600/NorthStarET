namespace NorthStar.EF6.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class new4 : DbMigration
    {
        public override void Up()
        {
            //DropForeignKey("dbo.AssessmentFieldCategory", "AssessmentId", "dbo.Assessment");
            //DropForeignKey("dbo.AssessmentFieldGroup", "AssessmentId", "dbo.Assessment");
            //DropForeignKey("dbo.AssessmentField", "AssessmentId", "dbo.Assessment");
            //DropForeignKey("dbo.AssessmentFieldSubCategory", "AssessmentId", "dbo.Assessment");
            //AddForeignKey("dbo.AssessmentFieldCategory", "AssessmentId", "dbo.Assessment", "Id", cascadeDelete: true);
            //AddForeignKey("dbo.AssessmentFieldGroup", "AssessmentId", "dbo.Assessment", "Id", cascadeDelete: true);
            //AddForeignKey("dbo.AssessmentField", "AssessmentId", "dbo.Assessment", "Id", cascadeDelete: true);
            //AddForeignKey("dbo.AssessmentFieldSubCategory", "AssessmentId", "dbo.Assessment", "Id", cascadeDelete: true);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.AssessmentFieldSubCategory", "AssessmentId", "dbo.Assessment");
            DropForeignKey("dbo.AssessmentField", "AssessmentId", "dbo.Assessment");
            DropForeignKey("dbo.AssessmentFieldGroup", "AssessmentId", "dbo.Assessment");
            DropForeignKey("dbo.AssessmentFieldCategory", "AssessmentId", "dbo.Assessment");
            AddForeignKey("dbo.AssessmentFieldSubCategory", "AssessmentId", "dbo.Assessment", "Id");
            AddForeignKey("dbo.AssessmentField", "AssessmentId", "dbo.Assessment", "Id");
            AddForeignKey("dbo.AssessmentFieldGroup", "AssessmentId", "dbo.Assessment", "Id");
            AddForeignKey("dbo.AssessmentFieldCategory", "AssessmentId", "dbo.Assessment", "Id");
        }
    }
}

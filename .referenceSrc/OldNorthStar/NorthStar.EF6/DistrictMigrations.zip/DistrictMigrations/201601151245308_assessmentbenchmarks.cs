namespace NorthStar.EF6.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class assessmentbenchmarks : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Assessment_Benchmarks",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        AssessmentID = c.Int(nullable: false),
                        GradeID = c.Int(nullable: false),
                        TestLevelPeriodID = c.Int(nullable: false),
                        TwentiethPercentileID = c.Int(),
                        MeanID = c.Int(),
                        EightiethPercentileID = c.Int(),
                        AssessmentField = c.String(unicode: false),
                        DecimalMean = c.Decimal(precision: 10, scale: 2),
                        Decimal20thPercentile = c.Decimal(precision: 10, scale: 2),
                        Decimal80thPercentile = c.Decimal(precision: 10, scale: 2),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Assessment", t => t.AssessmentID)
                .Index(t => t.AssessmentID);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Assessment_Benchmarks", "AssessmentID", "dbo.Assessment");
            DropIndex("dbo.Assessment_Benchmarks", new[] { "AssessmentID" });
            DropTable("dbo.Assessment_Benchmarks");
        }
    }
}

namespace NorthStar.EF6.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class staffschoolgrade : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.StaffSchoolGrade",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        SchoolID = c.Int(nullable: false),
                        StaffID = c.Int(nullable: false),
                        StaffHierarchyPermissionID = c.Int(nullable: false),
                        ModifiedDate = c.DateTime(),
                        Ip = c.String(),
                        ModifiedBy = c.String(),
                        Grade_Id = c.Int(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Grade", t => t.Grade_Id)
                .ForeignKey("dbo.School", t => t.SchoolID, cascadeDelete: true)
                .ForeignKey("dbo.Staff", t => t.StaffID, cascadeDelete: true)
                .Index(t => t.SchoolID)
                .Index(t => t.StaffID)
                .Index(t => t.Grade_Id);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.StaffSchoolGrade", "StaffID", "dbo.Staff");
            DropForeignKey("dbo.StaffSchoolGrade", "SchoolID", "dbo.School");
            DropForeignKey("dbo.StaffSchoolGrade", "Grade_Id", "dbo.Grade");
            DropIndex("dbo.StaffSchoolGrade", new[] { "Grade_Id" });
            DropIndex("dbo.StaffSchoolGrade", new[] { "StaffID" });
            DropIndex("dbo.StaffSchoolGrade", new[] { "SchoolID" });
            DropTable("dbo.StaffSchoolGrade");
        }
    }
}

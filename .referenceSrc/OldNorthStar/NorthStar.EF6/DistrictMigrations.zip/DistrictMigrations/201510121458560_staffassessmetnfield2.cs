namespace NorthStar.EF6.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class staffassessmetnfield2 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.AssessmentField", "DisplayInLineGraphs", c => c.Boolean());
            AddColumn("dbo.StaffAssessmentFieldVisibility", "DisplayInObsSummary", c => c.Boolean());
            AddColumn("dbo.StaffAssessmentFieldVisibility", "DisplayInEditResultList", c => c.Boolean());
            AddColumn("dbo.StaffAssessmentFieldVisibility", "DisplayInLineGraphs", c => c.Boolean());
            DropColumn("dbo.StaffAssessmentFieldVisibility", "HideFieldFromObservationSummary");
            DropColumn("dbo.StaffAssessmentFieldVisibility", "HideFieldFromEditResults");
            DropColumn("dbo.StaffAssessmentFieldVisibility", "HideFieldFromLineGraphs");
        }
        
        public override void Down()
        {
            AddColumn("dbo.StaffAssessmentFieldVisibility", "HideFieldFromLineGraphs", c => c.Boolean());
            AddColumn("dbo.StaffAssessmentFieldVisibility", "HideFieldFromEditResults", c => c.Boolean());
            AddColumn("dbo.StaffAssessmentFieldVisibility", "HideFieldFromObservationSummary", c => c.Boolean());
            DropColumn("dbo.StaffAssessmentFieldVisibility", "DisplayInLineGraphs");
            DropColumn("dbo.StaffAssessmentFieldVisibility", "DisplayInEditResultList");
            DropColumn("dbo.StaffAssessmentFieldVisibility", "DisplayInObsSummary");
            DropColumn("dbo.AssessmentField", "DisplayInLineGraphs");
        }
    }
}

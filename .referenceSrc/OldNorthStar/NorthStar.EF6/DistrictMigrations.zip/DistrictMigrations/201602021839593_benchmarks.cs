namespace NorthStar.EF6.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class benchmarks : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Assessment_Benchmarks", "DoesNotMeet", c => c.Decimal(precision: 10, scale: 2));
            AddColumn("dbo.Assessment_Benchmarks", "Approaches", c => c.Decimal(precision: 10, scale: 2));
            AddColumn("dbo.Assessment_Benchmarks", "Meets", c => c.Decimal(precision: 10, scale: 2));
            AddColumn("dbo.Assessment_Benchmarks", "Exceeds", c => c.Decimal(precision: 10, scale: 2));
            DropColumn("dbo.Assessment_Benchmarks", "TwentiethPercentileID");
            DropColumn("dbo.Assessment_Benchmarks", "MeanID");
            DropColumn("dbo.Assessment_Benchmarks", "EightiethPercentileID");
            DropColumn("dbo.Assessment_Benchmarks", "DecimalMean");
            DropColumn("dbo.Assessment_Benchmarks", "Decimal20thPercentile");
            DropColumn("dbo.Assessment_Benchmarks", "Decimal80thPercentile");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Assessment_Benchmarks", "Decimal80thPercentile", c => c.Decimal(precision: 10, scale: 2));
            AddColumn("dbo.Assessment_Benchmarks", "Decimal20thPercentile", c => c.Decimal(precision: 10, scale: 2));
            AddColumn("dbo.Assessment_Benchmarks", "DecimalMean", c => c.Decimal(precision: 10, scale: 2));
            AddColumn("dbo.Assessment_Benchmarks", "EightiethPercentileID", c => c.Int());
            AddColumn("dbo.Assessment_Benchmarks", "MeanID", c => c.Int());
            AddColumn("dbo.Assessment_Benchmarks", "TwentiethPercentileID", c => c.Int());
            DropColumn("dbo.Assessment_Benchmarks", "Exceeds");
            DropColumn("dbo.Assessment_Benchmarks", "Meets");
            DropColumn("dbo.Assessment_Benchmarks", "Approaches");
            DropColumn("dbo.Assessment_Benchmarks", "DoesNotMeet");
        }
    }
}

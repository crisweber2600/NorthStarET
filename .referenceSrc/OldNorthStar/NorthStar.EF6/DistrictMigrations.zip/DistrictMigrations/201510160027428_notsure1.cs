namespace NorthStar.EF6.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class notsure1 : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.TeamMeetingStudent", "SchoolID", "dbo.School");
            DropIndex("dbo.TeamMeetingStudent", new[] { "SchoolID" });
            DropColumn("dbo.TeamMeetingStudent", "SchoolID");
        }
        
        public override void Down()
        {
            AddColumn("dbo.TeamMeetingStudent", "SchoolID", c => c.Int(nullable: false));
            CreateIndex("dbo.TeamMeetingStudent", "SchoolID");
            AddForeignKey("dbo.TeamMeetingStudent", "SchoolID", "dbo.School", "Id", cascadeDelete: true);
        }
    }
}

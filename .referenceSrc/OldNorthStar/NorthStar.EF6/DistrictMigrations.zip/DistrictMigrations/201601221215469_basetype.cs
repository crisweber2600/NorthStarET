namespace NorthStar.EF6.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class basetype : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Assessment", "BaseType", c => c.Int(defaultValue: 100));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Assessment", "BaseType");
        }
    }
}

namespace NorthStar.EF6.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class fpcomparison : DbMigration
    {
        public override void Up()
        {
            //CreateTable(
            //    "dbo.FPComparison",
            //    c => new
            //        {
            //            ID = c.Int(nullable: false, identity: true),
            //            Grades = c.String(),
            //            DRAs = c.String(),
            //            RR = c.String(),
            //            FPs = c.String(),
            //            FPID = c.Int(nullable: false),
            //            Lexiles = c.String(),
            //            FPOrder = c.Int(nullable: false),
            //            DRAID = c.Int(nullable: false),
            //        })
            //    .PrimaryKey(t => t.ID);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.FPComparison");
        }
    }
}

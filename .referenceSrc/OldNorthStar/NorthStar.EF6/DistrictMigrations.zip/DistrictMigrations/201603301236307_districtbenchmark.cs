namespace NorthStar.EF6.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class districtbenchmark : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.District_Benchmark",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        AssessmentID = c.Int(nullable: false),
                        GradeID = c.Int(nullable: false),
                        TestLevelPeriodID = c.Int(nullable: false),
                        AssessmentField = c.String(),
                        DoesNotMeet = c.Decimal(precision: 18, scale: 2),
                        Approaches = c.Decimal(precision: 18, scale: 2),
                        Meets = c.Decimal(precision: 18, scale: 2),
                        Exceeds = c.Decimal(precision: 18, scale: 2),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Assessment", t => t.AssessmentID, cascadeDelete: true)
                .ForeignKey("dbo.Grade", t => t.GradeID, cascadeDelete: true)
                .ForeignKey("dbo.TestLevelPeriod", t => t.TestLevelPeriodID, cascadeDelete: true)
                .Index(t => t.AssessmentID)
                .Index(t => t.GradeID)
                .Index(t => t.TestLevelPeriodID);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.District_Benchmark", "TestLevelPeriodID", "dbo.TestLevelPeriod");
            DropForeignKey("dbo.District_Benchmark", "GradeID", "dbo.Grade");
            DropForeignKey("dbo.District_Benchmark", "AssessmentID", "dbo.Assessment");
            DropIndex("dbo.District_Benchmark", new[] { "TestLevelPeriodID" });
            DropIndex("dbo.District_Benchmark", new[] { "GradeID" });
            DropIndex("dbo.District_Benchmark", new[] { "AssessmentID" });
            DropTable("dbo.District_Benchmark");
        }
    }
}

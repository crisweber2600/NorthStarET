namespace NorthStar.EF6.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class tdd : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.TeamMeeting", "TestDueDateId", c => c.Int());
        }
        
        public override void Down()
        {
            DropColumn("dbo.TeamMeeting", "TestDueDateId");
        }
    }
}

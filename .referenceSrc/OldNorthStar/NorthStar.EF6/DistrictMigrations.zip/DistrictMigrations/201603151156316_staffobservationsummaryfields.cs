namespace NorthStar.EF6.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class staffobservationsummaryfields : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.StaffObservationSummaryAssessmentField",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        AssessmentId = c.Int(nullable: false),
                        AssessmentFieldId = c.Int(nullable: false),
                        StaffId = c.Int(nullable: false),
                        Hidden = c.Boolean(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Assessment", t => t.AssessmentId, cascadeDelete: true)
                .ForeignKey("dbo.AssessmentField", t => t.AssessmentFieldId, cascadeDelete: true)
                .ForeignKey("dbo.Staff", t => t.StaffId, cascadeDelete: true)
                .Index(t => t.AssessmentId)
                .Index(t => t.AssessmentFieldId)
                .Index(t => t.StaffId);
            
            CreateTable(
                "dbo.StaffObservationSummaryAssessment",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        AssessmentId = c.Int(nullable: false),
                        StaffId = c.Int(nullable: false),
                        Hidden = c.Boolean(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Assessment", t => t.AssessmentId, cascadeDelete: true)
                .ForeignKey("dbo.Staff", t => t.StaffId, cascadeDelete: true)
                .Index(t => t.AssessmentId)
                .Index(t => t.StaffId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.StaffObservationSummaryAssessment", "StaffId", "dbo.Staff");
            DropForeignKey("dbo.StaffObservationSummaryAssessment", "AssessmentId", "dbo.Assessment");
            DropForeignKey("dbo.StaffObservationSummaryAssessmentField", "StaffId", "dbo.Staff");
            DropForeignKey("dbo.StaffObservationSummaryAssessmentField", "AssessmentFieldId", "dbo.AssessmentField");
            DropForeignKey("dbo.StaffObservationSummaryAssessmentField", "AssessmentId", "dbo.Assessment");
            DropIndex("dbo.StaffObservationSummaryAssessment", new[] { "StaffId" });
            DropIndex("dbo.StaffObservationSummaryAssessment", new[] { "AssessmentId" });
            DropIndex("dbo.StaffObservationSummaryAssessmentField", new[] { "StaffId" });
            DropIndex("dbo.StaffObservationSummaryAssessmentField", new[] { "AssessmentFieldId" });
            DropIndex("dbo.StaffObservationSummaryAssessmentField", new[] { "AssessmentId" });
            DropTable("dbo.StaffObservationSummaryAssessment");
            DropTable("dbo.StaffObservationSummaryAssessmentField");
        }
    }
}

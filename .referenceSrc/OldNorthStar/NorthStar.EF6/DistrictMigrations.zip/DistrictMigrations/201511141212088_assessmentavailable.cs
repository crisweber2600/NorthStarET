namespace NorthStar.EF6.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class assessmentavailable : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.SchoolAssessment",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        AssessmentId = c.Int(nullable: false),
                        SchoolId = c.Int(nullable: false),
                        TestIsHidden = c.Boolean(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Assessment", t => t.AssessmentId, cascadeDelete: true)
                .Index(t => t.AssessmentId);
            
            CreateTable(
                "dbo.StaffAssessment",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        AssessmentId = c.Int(nullable: false),
                        StaffId = c.Int(nullable: false),
                        TestIsHidden = c.Boolean(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Assessment", t => t.AssessmentId, cascadeDelete: true)
                .Index(t => t.AssessmentId);
            
            AddColumn("dbo.Assessment", "AssessmentIsAvailable", c => c.Boolean());
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.StaffAssessment", "AssessmentId", "dbo.Assessment");
            DropForeignKey("dbo.SchoolAssessment", "AssessmentId", "dbo.Assessment");
            DropIndex("dbo.StaffAssessment", new[] { "AssessmentId" });
            DropIndex("dbo.SchoolAssessment", new[] { "AssessmentId" });
            DropColumn("dbo.Assessment", "AssessmentIsAvailable");
            DropTable("dbo.StaffAssessment");
            DropTable("dbo.SchoolAssessment");
        }
    }
}

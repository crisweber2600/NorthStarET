namespace NorthStar.EF6.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class assessmentavailable1 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.SchoolAssessment", "AssessmentIsAvailable", c => c.Boolean(nullable: false));
            AddColumn("dbo.StaffAssessment", "AssessmentIsAvailable", c => c.Boolean(nullable: false));
            DropColumn("dbo.SchoolAssessment", "TestIsHidden");
            DropColumn("dbo.StaffAssessment", "TestIsHidden");
        }
        
        public override void Down()
        {
            AddColumn("dbo.StaffAssessment", "TestIsHidden", c => c.Boolean(nullable: false));
            AddColumn("dbo.SchoolAssessment", "TestIsHidden", c => c.Boolean(nullable: false));
            DropColumn("dbo.StaffAssessment", "AssessmentIsAvailable");
            DropColumn("dbo.SchoolAssessment", "AssessmentIsAvailable");
        }
    }
}

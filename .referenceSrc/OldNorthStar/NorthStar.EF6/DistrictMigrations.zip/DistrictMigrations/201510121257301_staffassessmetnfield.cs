namespace NorthStar.EF6.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class staffassessmetnfield : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.StaffAssessmentFieldVisibility",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        StaffId = c.Int(nullable: false),
                        AssessmentId = c.Int(nullable: false),
                        AssessmentFieldId = c.Int(nullable: false),
                        HideFieldFromObservationSummary = c.Boolean(),
                        HideFieldFromEditResults = c.Boolean(),
                        HideFieldFromLineGraphs = c.Boolean(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Assessment", t => t.AssessmentId, cascadeDelete: true)
                .ForeignKey("dbo.AssessmentField", t => t.AssessmentFieldId, cascadeDelete: true)
                .ForeignKey("dbo.Staff", t => t.StaffId, cascadeDelete: true)
                .Index(t => t.StaffId)
                .Index(t => t.AssessmentId)
                .Index(t => t.AssessmentFieldId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.StaffAssessmentFieldVisibility", "StaffId", "dbo.Staff");
            DropForeignKey("dbo.StaffAssessmentFieldVisibility", "AssessmentFieldId", "dbo.AssessmentField");
            DropForeignKey("dbo.StaffAssessmentFieldVisibility", "AssessmentId", "dbo.Assessment");
            DropIndex("dbo.StaffAssessmentFieldVisibility", new[] { "AssessmentFieldId" });
            DropIndex("dbo.StaffAssessmentFieldVisibility", new[] { "AssessmentId" });
            DropIndex("dbo.StaffAssessmentFieldVisibility", new[] { "StaffId" });
            DropTable("dbo.StaffAssessmentFieldVisibility");
        }
    }
}

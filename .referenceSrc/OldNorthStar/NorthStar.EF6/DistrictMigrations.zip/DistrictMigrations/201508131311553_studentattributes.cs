namespace NorthStar.EF6.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class studentattributes : DbMigration
    {
        public override void Up()
        {
            //CreateTable(
            //    "dbo.StudentAttributeData",
            //    c => new
            //        {
            //            Id = c.Int(nullable: false, identity: true),
            //            StudentID = c.Int(nullable: false),
            //            AttributeID = c.Int(nullable: false),
            //            AttributeValue = c.Int(nullable: false),
            //            AttributeType_Id = c.Int(nullable: false),
            //            Value_Id = c.Int(nullable: false),
            //        })
            //    .PrimaryKey(t => t.Id)
            //    .ForeignKey("dbo.StudentAttributeType", t => t.AttributeType_Id, cascadeDelete: true)
            //    .ForeignKey("dbo.StudentAttributeLookupValue", t => t.Value_Id, cascadeDelete: true)
            //    .ForeignKey("dbo.Student", t => t.AttributeID)
            //    .Index(t => t.AttributeID)
            //    .Index(t => t.AttributeType_Id)
            //    .Index(t => t.Value_Id);
            
            //CreateTable(
            //    "dbo.StudentAttributeType",
            //    c => new
            //        {
            //            Id = c.Int(nullable: false, identity: true),
            //            AttributeName = c.String(),
            //        })
            //    .PrimaryKey(t => t.Id);
            
            //CreateTable(
            //    "dbo.StudentAttributeLookupValue",
            //    c => new
            //        {
            //            Id = c.Int(nullable: false, identity: true),
            //            AttributeID = c.Int(nullable: false),
            //            LookupValueID = c.Int(),
            //            LookupValue = c.String(),
            //            Description = c.String(),
            //        })
            //    .PrimaryKey(t => t.Id);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.StudentAttributeData", "AttributeID", "dbo.Student");
            DropForeignKey("dbo.StudentAttributeData", "Value_Id", "dbo.StudentAttributeLookupValue");
            DropForeignKey("dbo.StudentAttributeData", "AttributeType_Id", "dbo.StudentAttributeType");
            DropIndex("dbo.StudentAttributeData", new[] { "Value_Id" });
            DropIndex("dbo.StudentAttributeData", new[] { "AttributeType_Id" });
            DropIndex("dbo.StudentAttributeData", new[] { "AttributeID" });
            DropTable("dbo.StudentAttributeLookupValue");
            DropTable("dbo.StudentAttributeType");
            DropTable("dbo.StudentAttributeData");
        }
    }
}

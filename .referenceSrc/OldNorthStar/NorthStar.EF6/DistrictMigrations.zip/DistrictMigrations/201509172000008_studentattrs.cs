namespace NorthStar.EF6.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class studentattrs : DbMigration
    {
        public override void Up()
        {
            //DropIndex("dbo.StudentAttributeData", new[] { "AttributeType_Id" });
            //DropColumn("dbo.StudentAttributeData", "AttributeID");
            //RenameColumn(table: "dbo.StudentAttributeData", name: "AttributeType_Id", newName: "AttributeID");
        }
        
        public override void Down()
        {
            //RenameColumn(table: "dbo.StudentAttributeData", name: "AttributeID", newName: "AttributeType_Id");
            //AddColumn("dbo.StudentAttributeData", "AttributeID", c => c.Int(nullable: false));
            //CreateIndex("dbo.StudentAttributeData", "AttributeType_Id");
        }
    }
}

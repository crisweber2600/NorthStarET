namespace NorthStar.EF6.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class studentattributes1 : DbMigration
    {
        public override void Up()
        {
            //AddColumn("dbo.StudentAttributeData", "AttributeValueID", c => c.Int(nullable: false));
            //DropColumn("dbo.StudentAttributeData", "AttributeValue");
        }
        
        public override void Down()
        {
            AddColumn("dbo.StudentAttributeData", "AttributeValue", c => c.Int(nullable: false));
            DropColumn("dbo.StudentAttributeData", "AttributeValueID");
        }
    }
}

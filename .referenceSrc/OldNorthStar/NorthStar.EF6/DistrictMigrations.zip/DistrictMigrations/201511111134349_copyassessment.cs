namespace NorthStar.EF6.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class copyassessment : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.AssessmentFieldCategory", "PreviousId", c => c.Int());
            AddColumn("dbo.AssessmentField", "PreviousId", c => c.Int());
            AddColumn("dbo.AssessmentFieldGroup", "PreviousId", c => c.Int());
            AddColumn("dbo.AssessmentFieldSubCategory", "PreviousId", c => c.Int());
            AddColumn("dbo.Assessment", "TestType", c => c.Int());
        }
        
        public override void Down()
        {
            DropColumn("dbo.Assessment", "TestType");
            DropColumn("dbo.AssessmentFieldSubCategory", "PreviousId");
            DropColumn("dbo.AssessmentFieldGroup", "PreviousId");
            DropColumn("dbo.AssessmentField", "PreviousId");
            DropColumn("dbo.AssessmentFieldCategory", "PreviousId");
        }
    }
}

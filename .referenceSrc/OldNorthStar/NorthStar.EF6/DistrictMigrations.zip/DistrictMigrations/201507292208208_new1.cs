namespace NorthStar.EF6.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class new1 : DbMigration
    {
        public override void Up()
        {
            //CreateTable(
            //    "dbo.AttendanceReason",
            //    c => new
            //        {
            //            Id = c.Int(nullable: false, identity: true),
            //            Reason = c.String(),
            //            ValidForScheduledDays = c.Boolean(nullable: false),
            //            CountsAsAbsense = c.Boolean(nullable: false),
            //            ValidForNonScheduledDays = c.Boolean(nullable: false),
            //            CountsAsBonusDay = c.Boolean(nullable: false),
            //            Order = c.Int(nullable: false),
            //            ModifiedDate = c.DateTime(),
            //            Ip = c.String(),
            //            ModifiedBy = c.String(),
            //        })
            //    .PrimaryKey(t => t.Id);
            
            //CreateTable(
            //    "dbo.DistrictCalendar",
            //    c => new
            //        {
            //            Id = c.Int(nullable: false, identity: true),
            //            Subject = c.String(),
            //            Description = c.String(),
            //            Start = c.DateTime(nullable: false),
            //            End = c.DateTime(nullable: false),
            //            ModifiedDate = c.DateTime(),
            //            Ip = c.String(),
            //            ModifiedBy = c.String(),
            //        })
            //    .PrimaryKey(t => t.Id);
            
            //CreateTable(
            //    "dbo.InterventionAttendance",
            //    c => new
            //        {
            //            Id = c.Int(nullable: false, identity: true),
            //            SectionID = c.Int(nullable: false),
            //            Notes = c.String(),
            //            AttendanceDate = c.DateTime(nullable: false),
            //            AttendanceReasonID = c.Int(nullable: false),
            //            StudentID = c.Int(nullable: false),
            //            RecorderID = c.Int(nullable: false),
            //            Contact = c.Boolean(),
            //            ClassStartEndID = c.Int(),
            //            ModifiedDate = c.DateTime(),
            //            Ip = c.String(),
            //            ModifiedBy = c.String(),
            //        })
            //    .PrimaryKey(t => t.Id);
            
            //CreateTable(
            //    "dbo.InterventionTier",
            //    c => new
            //        {
            //            Id = c.Int(nullable: false, identity: true),
            //            TierValue = c.Int(nullable: false),
            //            Description = c.String(),
            //            TierName = c.String(),
            //            TierLabel = c.String(),
            //            TierColor = c.String(),
            //        })
            //    .PrimaryKey(t => t.Id);
            
            //CreateTable(
            //    "dbo.SchoolCalendar",
            //    c => new
            //        {
            //            Id = c.Int(nullable: false, identity: true),
            //            SchoolID = c.Int(nullable: false),
            //            Subject = c.String(),
            //            Description = c.String(),
            //            Start = c.DateTime(nullable: false),
            //            End = c.DateTime(nullable: false),
            //            ModifiedDate = c.DateTime(),
            //            Ip = c.String(),
            //            ModifiedBy = c.String(),
            //        })
            //    .PrimaryKey(t => t.Id)
            //    .ForeignKey("dbo.School", t => t.SchoolID, cascadeDelete: true)
            //    .Index(t => t.SchoolID);
            
            //CreateTable(
            //    "dbo.School",
            //    c => new
            //        {
            //            Id = c.Int(nullable: false, identity: true),
            //            Name = c.String(),
            //            Description = c.String(),
            //            ModifiedDate = c.DateTime(),
            //            Ip = c.String(),
            //            ModifiedBy = c.String(),
            //        })
            //    .PrimaryKey(t => t.Id);
            
            //CreateTable(
            //    "dbo.SchoolYear",
            //    c => new
            //        {
            //            SchoolStartYear = c.Int(nullable: false),
            //            YearVerbose = c.String(),
            //            SchoolEndYear = c.Int(nullable: false),
            //            ModifiedDate = c.DateTime(),
            //            Ip = c.String(),
            //            ModifiedBy = c.String(),
            //        })
            //    .PrimaryKey(t => t.SchoolStartYear);
            
            //CreateTable(
            //    "dbo.Staff",
            //    c => new
            //        {
            //            Id = c.Int(nullable: false, identity: true),
            //            TeacherIdentifier = c.String(),
            //            LoweredUserName = c.String(),
            //            FirstName = c.String(),
            //            MiddleName = c.String(),
            //            LastName = c.String(),
            //            NorthStarUserTypeID = c.Int(),
            //            Notes = c.String(),
            //            RoleID = c.Int(nullable: false),
            //            Email = c.String(),
            //            IsInterventionSpecialist = c.Boolean(nullable: false),
            //            NavigationFavorites = c.String(),
            //            RolesLastUpdated = c.DateTime(),
            //            IsActive = c.Boolean(),
            //            ModifiedDate = c.DateTime(),
            //            Ip = c.String(),
            //            ModifiedBy = c.String(),
            //        })
            //    .PrimaryKey(t => t.Id);
            
            //CreateTable(
            //    "dbo.StaffSchool",
            //    c => new
            //        {
            //            Id = c.Int(nullable: false, identity: true),
            //            SchoolID = c.Int(nullable: false),
            //            StaffID = c.Int(nullable: false),
            //            StaffHierarchyPermissionID = c.Int(nullable: false),
            //            ModifiedDate = c.DateTime(),
            //            Ip = c.String(),
            //            ModifiedBy = c.String(),
            //        })
            //    .PrimaryKey(t => t.Id)
            //    .ForeignKey("dbo.School", t => t.SchoolID, cascadeDelete: true)
            //    .ForeignKey("dbo.Staff", t => t.StaffID, cascadeDelete: true)
            //    .Index(t => t.SchoolID)
            //    .Index(t => t.StaffID);
            
            //CreateTable(
            //    "dbo.StaffSection",
            //    c => new
            //        {
            //            Id = c.Int(nullable: false, identity: true),
            //            StaffID = c.Int(nullable: false),
            //            ClassID = c.Int(nullable: false),
            //            StaffHierarchyPermissionID = c.Int(nullable: false),
            //            ModifiedDate = c.DateTime(),
            //            Ip = c.String(),
            //            ModifiedBy = c.String(),
            //            Section_Id = c.Int(),
            //        })
            //    .PrimaryKey(t => t.Id)
            //    .ForeignKey("dbo.Section", t => t.Section_Id)
            //    .ForeignKey("dbo.Staff", t => t.StaffID, cascadeDelete: true)
            //    .Index(t => t.StaffID)
            //    .Index(t => t.Section_Id);
            
            //CreateTable(
            //    "dbo.Section",
            //    c => new
            //        {
            //            Id = c.Int(nullable: false, identity: true),
            //            Name = c.String(),
            //            Description = c.String(),
            //            StaffID = c.Int(nullable: false),
            //            SchoolStartYear = c.Int(nullable: false),
            //            SchoolID = c.Int(nullable: false),
            //            GradeID = c.Int(nullable: false),
            //            SectionDataTypeID = c.Int(nullable: false),
            //            InterventionTypeID = c.Int(),
            //            InterventionTierID = c.Int(),
            //            StartDate = c.DateTime(),
            //            EndDate = c.DateTime(),
            //            StaffTimeSlotID = c.Int(),
            //            IsInterventionGroup = c.Boolean(nullable: false),
            //            InterventionDistrictID = c.Int(),
            //            MondayMeet = c.Boolean(),
            //            TuesdayMeet = c.Boolean(),
            //            WednesdayMeet = c.Boolean(),
            //            ThursdayMeet = c.Boolean(),
            //            FridayMeet = c.Boolean(),
            //            StartTime = c.DateTime(),
            //            EndTime = c.DateTime(),
            //            ModifiedDate = c.DateTime(),
            //            Ip = c.String(),
            //            ModifiedBy = c.String(),
            //        })
            //    .PrimaryKey(t => t.Id)
            //    .ForeignKey("dbo.Grade", t => t.GradeID, cascadeDelete: true)
            //    .ForeignKey("dbo.School", t => t.SchoolID, cascadeDelete: true)
            //    .ForeignKey("dbo.SchoolYear", t => t.SchoolStartYear, cascadeDelete: true)
            //    .ForeignKey("dbo.Staff", t => t.StaffID, cascadeDelete: true)
            //    .Index(t => t.StaffID)
            //    .Index(t => t.SchoolStartYear)
            //    .Index(t => t.SchoolID)
            //    .Index(t => t.GradeID);
            
            //CreateTable(
            //    "dbo.Grade",
            //    c => new
            //        {
            //            Id = c.Int(nullable: false, identity: true),
            //            ShortName = c.String(),
            //            LongName = c.String(),
            //            GradeOrder = c.Int(nullable: false),
            //            StateGradeNumber = c.Int(),
            //            ModifiedDate = c.DateTime(),
            //            Ip = c.String(),
            //            ModifiedBy = c.String(),
            //        })
            //    .PrimaryKey(t => t.Id);
            
            //CreateTable(
            //    "dbo.StudentSection",
            //    c => new
            //        {
            //            Id = c.Int(nullable: false, identity: true),
            //            StudentID = c.Int(nullable: false),
            //            ClassID = c.Int(nullable: false),
            //            StartDate = c.DateTime(),
            //            EndDate = c.DateTime(),
            //            LastAssociatedTDDID = c.Int(),
            //            Notes = c.String(),
            //            LastAssociatedTDD = c.DateTime(),
            //            ModifiedDate = c.DateTime(),
            //            Ip = c.String(),
            //            ModifiedBy = c.String(),
            //            Section_Id = c.Int(),
            //        })
            //    .PrimaryKey(t => t.Id)
            //    .ForeignKey("dbo.Section", t => t.Section_Id)
            //    .ForeignKey("dbo.Student", t => t.StudentID, cascadeDelete: true)
            //    .Index(t => t.StudentID)
            //    .Index(t => t.Section_Id);
            
            //CreateTable(
            //    "dbo.Student",
            //    c => new
            //        {
            //            Id = c.Int(nullable: false, identity: true),
            //            FirstName = c.String(),
            //            MiddleName = c.String(),
            //            LastName = c.String(),
            //            DOB = c.DateTime(),
            //            GradYear = c.Int(),
            //            StudentIdentifier = c.String(),
            //            TitleOnetypeID = c.Int(),
            //            Comment = c.String(),
            //            EthnicityID = c.Int(),
            //            Gender = c.String(),
            //            IsActive = c.Boolean(),
            //            GenderID = c.Int(),
            //            DistrictID = c.Int(),
            //            ELL = c.Boolean(),
            //            ADSIS = c.Boolean(),
            //            Gifted = c.Boolean(),
            //            ModifiedDate = c.DateTime(),
            //            Ip = c.String(),
            //            ModifiedBy = c.String(),
            //        })
            //    .PrimaryKey(t => t.Id);
            
            //CreateTable(
            //    "dbo.StudentSchool",
            //    c => new
            //        {
            //            Id = c.Int(nullable: false, identity: true),
            //            StudentID = c.Int(nullable: false),
            //            SchoolID = c.Int(nullable: false),
            //            SchoolStartYear = c.Int(nullable: false),
            //            StartDate = c.DateTime(),
            //            EndDate = c.DateTime(),
            //            ModifiedDate = c.DateTime(),
            //            Ip = c.String(),
            //            ModifiedBy = c.String(),
            //        })
            //    .PrimaryKey(t => t.Id)
            //    .ForeignKey("dbo.School", t => t.SchoolID, cascadeDelete: true)
            //    .ForeignKey("dbo.Student", t => t.StudentID, cascadeDelete: true)
            //    .Index(t => t.StudentID)
            //    .Index(t => t.SchoolID);
            
            //CreateTable(
            //    "dbo.Assessment",
            //    c => new
            //        {
            //            Id = c.Int(nullable: false, identity: true),
            //            StorageTable = c.String(),
            //            SecondaryStorageTable = c.String(),
            //            TertiaryStorageTable = c.String(),
            //            IsStateTest = c.Boolean(),
            //            IsHFW = c.Boolean(),
            //            IsProgressMonitoring = c.Boolean(),
            //            AssessmentName = c.String(),
            //            AssessmentDescription = c.String(),
            //            DefaultDataEntryPage = c.String(),
            //            DataEntryPages = c.String(),
            //            DefaultClassReportPage = c.String(),
            //            ClassReportPages = c.String(),
            //            ModifiedDate = c.DateTime(),
            //            Ip = c.String(),
            //            ModifiedBy = c.String(),
            //        })
            //    .PrimaryKey(t => t.Id);
            
            //CreateTable(
            //    "dbo.AssessmentFieldCategory",
            //    c => new
            //        {
            //            Id = c.Int(nullable: false, identity: true),
            //            AssessmentId = c.Int(nullable: false),
            //            SortOrder = c.Int(nullable: false),
            //            AltOrder = c.Int(),
            //            DisplayName = c.String(),
            //            AltDisplayLabel = c.String(),
            //            Description = c.String(),
            //            ModifiedDate = c.DateTime(),
            //            Ip = c.String(),
            //            ModifiedBy = c.String(),
            //        })
            //    .PrimaryKey(t => t.Id)
            //    .ForeignKey("dbo.Assessment", t => t.AssessmentId)
            //    .Index(t => t.AssessmentId);
            
            //CreateTable(
            //    "dbo.AssessmentField",
            //    c => new
            //        {
            //            Id = c.Int(nullable: false, identity: true),
            //            StorageTable = c.String(),
            //            DisplayLabel = c.String(),
            //            AltDisplayLabel = c.String(),
            //            FieldType = c.String(),
            //            DefaultValue = c.String(),
            //            IsRequired = c.Boolean(nullable: false),
            //            CategoryId = c.Int(),
            //            SubcategoryId = c.Int(),
            //            GroupId = c.Int(),
            //            Page = c.Int(nullable: false),
            //            FieldOrder = c.Int(nullable: false),
            //            AltOrder = c.Int(),
            //            Description = c.String(),
            //            LookupFieldName = c.String(),
            //            RangeHigh = c.Int(nullable: false),
            //            RangeLow = c.Int(nullable: false),
            //            DatabaseColumn = c.String(),
            //            CalculationFunction = c.String(),
            //            CalculationFields = c.String(),
            //            AssessmentId = c.Int(nullable: false),
            //            DisplayInObsSummary = c.Boolean(),
            //            DisplayInEditResultList = c.Boolean(),
            //            OutOfHowMany = c.Int(),
            //            ModifiedDate = c.DateTime(),
            //            Ip = c.String(),
            //            ModifiedBy = c.String(),
            //        })
            //    .PrimaryKey(t => t.Id)
            //    .ForeignKey("dbo.AssessmentFieldGroup", t => t.GroupId)
            //    .ForeignKey("dbo.AssessmentFieldSubCategory", t => t.SubcategoryId)
            //    .ForeignKey("dbo.AssessmentFieldCategory", t => t.CategoryId)
            //    .ForeignKey("dbo.Assessment", t => t.AssessmentId)
            //    .Index(t => t.CategoryId)
            //    .Index(t => t.SubcategoryId)
            //    .Index(t => t.GroupId)
            //    .Index(t => t.AssessmentId);
            
            //CreateTable(
            //    "dbo.AssessmentFieldGroup",
            //    c => new
            //        {
            //            Id = c.Int(nullable: false, identity: true),
            //            AssessmentId = c.Int(nullable: false),
            //            SortOrder = c.Int(nullable: false),
            //            AltOrder = c.Int(),
            //            DisplayName = c.String(),
            //            AltDisplayLabel = c.String(),
            //            Description = c.String(),
            //            ModifiedDate = c.DateTime(),
            //            Ip = c.String(),
            //            ModifiedBy = c.String(),
            //        })
            //    .PrimaryKey(t => t.Id)
            //    .ForeignKey("dbo.Assessment", t => t.AssessmentId)
            //    .Index(t => t.AssessmentId);
            
            //CreateTable(
            //    "dbo.AssessmentFieldSubCategory",
            //    c => new
            //        {
            //            Id = c.Int(nullable: false, identity: true),
            //            AssessmentId = c.Int(nullable: false),
            //            SortOrder = c.Int(nullable: false),
            //            AltOrder = c.Int(),
            //            DisplayName = c.String(),
            //            AltDisplayLabel = c.String(),
            //            Description = c.String(),
            //            ModifiedDate = c.DateTime(),
            //            Ip = c.String(),
            //            ModifiedBy = c.String(),
            //        })
            //    .PrimaryKey(t => t.Id)
            //    .ForeignKey("dbo.Assessment", t => t.AssessmentId)
            //    .Index(t => t.AssessmentId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.AssessmentFieldSubCategory", "AssessmentId", "dbo.Assessment");
            DropForeignKey("dbo.AssessmentField", "AssessmentId", "dbo.Assessment");
            DropForeignKey("dbo.AssessmentFieldGroup", "AssessmentId", "dbo.Assessment");
            DropForeignKey("dbo.AssessmentFieldCategory", "AssessmentId", "dbo.Assessment");
            DropForeignKey("dbo.AssessmentField", "CategoryId", "dbo.AssessmentFieldCategory");
            DropForeignKey("dbo.AssessmentField", "SubcategoryId", "dbo.AssessmentFieldSubCategory");
            DropForeignKey("dbo.AssessmentField", "GroupId", "dbo.AssessmentFieldGroup");
            DropForeignKey("dbo.StudentSchool", "StudentID", "dbo.Student");
            DropForeignKey("dbo.StudentSchool", "SchoolID", "dbo.School");
            DropForeignKey("dbo.StaffSection", "StaffID", "dbo.Staff");
            DropForeignKey("dbo.StudentSection", "StudentID", "dbo.Student");
            DropForeignKey("dbo.StudentSection", "Section_Id", "dbo.Section");
            DropForeignKey("dbo.StaffSection", "Section_Id", "dbo.Section");
            DropForeignKey("dbo.Section", "StaffID", "dbo.Staff");
            DropForeignKey("dbo.Section", "SchoolStartYear", "dbo.SchoolYear");
            DropForeignKey("dbo.Section", "SchoolID", "dbo.School");
            DropForeignKey("dbo.Section", "GradeID", "dbo.Grade");
            DropForeignKey("dbo.StaffSchool", "StaffID", "dbo.Staff");
            DropForeignKey("dbo.StaffSchool", "SchoolID", "dbo.School");
            DropForeignKey("dbo.SchoolCalendar", "SchoolID", "dbo.School");
            DropIndex("dbo.AssessmentFieldSubCategory", new[] { "AssessmentId" });
            DropIndex("dbo.AssessmentFieldGroup", new[] { "AssessmentId" });
            DropIndex("dbo.AssessmentField", new[] { "AssessmentId" });
            DropIndex("dbo.AssessmentField", new[] { "GroupId" });
            DropIndex("dbo.AssessmentField", new[] { "SubcategoryId" });
            DropIndex("dbo.AssessmentField", new[] { "CategoryId" });
            DropIndex("dbo.AssessmentFieldCategory", new[] { "AssessmentId" });
            DropIndex("dbo.StudentSchool", new[] { "SchoolID" });
            DropIndex("dbo.StudentSchool", new[] { "StudentID" });
            DropIndex("dbo.StudentSection", new[] { "Section_Id" });
            DropIndex("dbo.StudentSection", new[] { "StudentID" });
            DropIndex("dbo.Section", new[] { "GradeID" });
            DropIndex("dbo.Section", new[] { "SchoolID" });
            DropIndex("dbo.Section", new[] { "SchoolStartYear" });
            DropIndex("dbo.Section", new[] { "StaffID" });
            DropIndex("dbo.StaffSection", new[] { "Section_Id" });
            DropIndex("dbo.StaffSection", new[] { "StaffID" });
            DropIndex("dbo.StaffSchool", new[] { "StaffID" });
            DropIndex("dbo.StaffSchool", new[] { "SchoolID" });
            DropIndex("dbo.SchoolCalendar", new[] { "SchoolID" });
            DropTable("dbo.AssessmentFieldSubCategory");
            DropTable("dbo.AssessmentFieldGroup");
            DropTable("dbo.AssessmentField");
            DropTable("dbo.AssessmentFieldCategory");
            DropTable("dbo.Assessment");
            DropTable("dbo.StudentSchool");
            DropTable("dbo.Student");
            DropTable("dbo.StudentSection");
            DropTable("dbo.Grade");
            DropTable("dbo.Section");
            DropTable("dbo.StaffSection");
            DropTable("dbo.StaffSchool");
            DropTable("dbo.Staff");
            DropTable("dbo.SchoolYear");
            DropTable("dbo.School");
            DropTable("dbo.SchoolCalendar");
            DropTable("dbo.InterventionTier");
            DropTable("dbo.InterventionAttendance");
            DropTable("dbo.DistrictCalendar");
            DropTable("dbo.AttendanceReason");
        }
    }
}

namespace NorthStar.EF6.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class teammeetings : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.TeamMeetingAttendance",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        TeamMeetingID = c.Int(nullable: false),
                        StaffID = c.Int(nullable: false),
                        NoticeSent = c.DateTime(),
                        Attended = c.Boolean(nullable: false),
                        SchoolID = c.Int(),
                        IncludeAllStudents = c.Boolean(nullable: false),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.School", t => t.SchoolID)
                .ForeignKey("dbo.Staff", t => t.StaffID, cascadeDelete: true)
                .ForeignKey("dbo.TeamMeeting", t => t.TeamMeetingID)
                .Index(t => t.TeamMeetingID)
                .Index(t => t.StaffID)
                .Index(t => t.SchoolID);
            
            CreateTable(
                "dbo.TeamMeeting",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        Title = c.String(),
                        Comments = c.String(),
                        MeetingTime = c.DateTime(nullable: false),
                        StaffID = c.Int(nullable: false),
                        SchoolYear = c.Short(nullable: false),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.Staff", t => t.StaffID, cascadeDelete: true)
                .Index(t => t.StaffID);
            
            CreateTable(
                "dbo.TeamMeetingManager",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        TeamMeetingID = c.Int(nullable: false),
                        StaffID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.Staff", t => t.StaffID, cascadeDelete: true)
                .ForeignKey("dbo.TeamMeeting", t => t.TeamMeetingID)
                .Index(t => t.TeamMeetingID)
                .Index(t => t.StaffID);
            
            CreateTable(
                "dbo.TeamMeetingStudentNote",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        TeamMeetingID = c.Int(nullable: false),
                        StudentID = c.Int(nullable: false),
                        NoteDate = c.DateTime(nullable: false),
                        Note = c.String(unicode: false),
                        StaffID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.Staff", t => t.StaffID, cascadeDelete: true)
                .ForeignKey("dbo.Student", t => t.StudentID, cascadeDelete: true)
                .ForeignKey("dbo.TeamMeeting", t => t.TeamMeetingID)
                .Index(t => t.TeamMeetingID)
                .Index(t => t.StudentID)
                .Index(t => t.StaffID);
            
            CreateTable(
                "dbo.TeamMeetingStudent",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        TeamMeetingID = c.Int(nullable: false),
                        SchoolID = c.Int(nullable: false),
                        StaffID = c.Int(nullable: false),
                        SectionID = c.Int(nullable: false),
                        StudentID = c.Int(nullable: false),
                        Notes = c.String(),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.School", t => t.SchoolID, cascadeDelete: true)
                .ForeignKey("dbo.Section", t => t.SectionID, cascadeDelete: true)
                .ForeignKey("dbo.Staff", t => t.StaffID, cascadeDelete: true)
                .ForeignKey("dbo.Student", t => t.StudentID, cascadeDelete: true)
                .ForeignKey("dbo.TeamMeeting", t => t.TeamMeetingID)
                .Index(t => t.TeamMeetingID)
                .Index(t => t.SchoolID)
                .Index(t => t.StaffID)
                .Index(t => t.SectionID)
                .Index(t => t.StudentID);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.TeamMeetingStudent", "TeamMeetingID", "dbo.TeamMeeting");
            DropForeignKey("dbo.TeamMeetingStudent", "StudentID", "dbo.Student");
            DropForeignKey("dbo.TeamMeetingStudent", "StaffID", "dbo.Staff");
            DropForeignKey("dbo.TeamMeetingStudent", "SectionID", "dbo.Section");
            DropForeignKey("dbo.TeamMeetingStudent", "SchoolID", "dbo.School");
            DropForeignKey("dbo.TeamMeetingStudentNote", "TeamMeetingID", "dbo.TeamMeeting");
            DropForeignKey("dbo.TeamMeetingStudentNote", "StudentID", "dbo.Student");
            DropForeignKey("dbo.TeamMeetingStudentNote", "StaffID", "dbo.Staff");
            DropForeignKey("dbo.TeamMeetingManager", "TeamMeetingID", "dbo.TeamMeeting");
            DropForeignKey("dbo.TeamMeetingManager", "StaffID", "dbo.Staff");
            DropForeignKey("dbo.TeamMeetingAttendance", "TeamMeetingID", "dbo.TeamMeeting");
            DropForeignKey("dbo.TeamMeeting", "StaffID", "dbo.Staff");
            DropForeignKey("dbo.TeamMeetingAttendance", "StaffID", "dbo.Staff");
            DropForeignKey("dbo.TeamMeetingAttendance", "SchoolID", "dbo.School");
            DropIndex("dbo.TeamMeetingStudent", new[] { "StudentID" });
            DropIndex("dbo.TeamMeetingStudent", new[] { "SectionID" });
            DropIndex("dbo.TeamMeetingStudent", new[] { "StaffID" });
            DropIndex("dbo.TeamMeetingStudent", new[] { "SchoolID" });
            DropIndex("dbo.TeamMeetingStudent", new[] { "TeamMeetingID" });
            DropIndex("dbo.TeamMeetingStudentNote", new[] { "StaffID" });
            DropIndex("dbo.TeamMeetingStudentNote", new[] { "StudentID" });
            DropIndex("dbo.TeamMeetingStudentNote", new[] { "TeamMeetingID" });
            DropIndex("dbo.TeamMeetingManager", new[] { "StaffID" });
            DropIndex("dbo.TeamMeetingManager", new[] { "TeamMeetingID" });
            DropIndex("dbo.TeamMeeting", new[] { "StaffID" });
            DropIndex("dbo.TeamMeetingAttendance", new[] { "SchoolID" });
            DropIndex("dbo.TeamMeetingAttendance", new[] { "StaffID" });
            DropIndex("dbo.TeamMeetingAttendance", new[] { "TeamMeetingID" });
            DropTable("dbo.TeamMeetingStudent");
            DropTable("dbo.TeamMeetingStudentNote");
            DropTable("dbo.TeamMeetingManager");
            DropTable("dbo.TeamMeeting");
            DropTable("dbo.TeamMeetingAttendance");
        }
    }
}

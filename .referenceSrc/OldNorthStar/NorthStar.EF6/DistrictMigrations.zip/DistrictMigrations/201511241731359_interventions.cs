namespace NorthStar.EF6.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class interventions : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.InterventionGroup",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                        Description = c.String(),
                        StaffID = c.Int(nullable: false),
                        SchoolStartYear = c.Int(nullable: false),
                        SchoolID = c.Int(nullable: false),
                        SectionDataTypeID = c.Int(nullable: false),
                        InterventionTypeID = c.Int(),
                        InterventionTierID = c.Int(),
                        StartDate = c.DateTime(),
                        EndDate = c.DateTime(),
                        StaffTimeSlotID = c.Int(),
                        IsInterventionGroup = c.Boolean(nullable: false),
                        InterventionDistrictID = c.Int(),
                        MondayMeet = c.Boolean(),
                        TuesdayMeet = c.Boolean(),
                        WednesdayMeet = c.Boolean(),
                        ThursdayMeet = c.Boolean(),
                        FridayMeet = c.Boolean(),
                        StartTime = c.DateTime(),
                        EndTime = c.DateTime(),
                        ModifiedDate = c.DateTime(),
                        Ip = c.String(),
                        ModifiedBy = c.String(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.InterventionType", t => t.InterventionTypeID)
                .ForeignKey("dbo.School", t => t.SchoolID)
                .ForeignKey("dbo.SchoolYear", t => t.SchoolStartYear, cascadeDelete: true)
                .ForeignKey("dbo.Staff", t => t.StaffID, cascadeDelete: true)
                .Index(t => t.StaffID)
                .Index(t => t.SchoolStartYear)
                .Index(t => t.SchoolID)
                .Index(t => t.InterventionTypeID);
            
            CreateTable(
                "dbo.StaffInterventionGroup",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        StaffID = c.Int(nullable: false),
                        InterventionGroupId = c.Int(nullable: false),
                        StaffHierarchyPermissionID = c.Int(nullable: false),
                        ModifiedDate = c.DateTime(),
                        Ip = c.String(),
                        ModifiedBy = c.String(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Staff", t => t.StaffID, cascadeDelete: true)
                .ForeignKey("dbo.InterventionGroup", t => t.InterventionGroupId)
                .Index(t => t.StaffID)
                .Index(t => t.InterventionGroupId);
            
            CreateTable(
                "dbo.StudentInterventionGroup",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        StudentID = c.Int(nullable: false),
                        InterventionGroupId = c.Int(nullable: false),
                        StartDate = c.DateTime(),
                        EndDate = c.DateTime(),
                        LastAssociatedTDDID = c.Int(),
                        Notes = c.String(),
                        LastAssociatedTDD = c.DateTime(),
                        ModifiedDate = c.DateTime(),
                        Ip = c.String(),
                        ModifiedBy = c.String(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Student", t => t.StudentID, cascadeDelete: true)
                .ForeignKey("dbo.InterventionGroup", t => t.InterventionGroupId)
                .Index(t => t.StudentID)
                .Index(t => t.InterventionGroupId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.StudentInterventionGroup", "InterventionGroupId", "dbo.InterventionGroup");
            DropForeignKey("dbo.StudentInterventionGroup", "StudentID", "dbo.Student");
            DropForeignKey("dbo.StaffInterventionGroup", "InterventionGroupId", "dbo.InterventionGroup");
            DropForeignKey("dbo.StaffInterventionGroup", "StaffID", "dbo.Staff");
            DropForeignKey("dbo.InterventionGroup", "StaffID", "dbo.Staff");
            DropForeignKey("dbo.InterventionGroup", "SchoolStartYear", "dbo.SchoolYear");
            DropForeignKey("dbo.InterventionGroup", "SchoolID", "dbo.School");
            DropForeignKey("dbo.InterventionGroup", "InterventionTypeID", "dbo.InterventionType");
            DropIndex("dbo.StudentInterventionGroup", new[] { "InterventionGroupId" });
            DropIndex("dbo.StudentInterventionGroup", new[] { "StudentID" });
            DropIndex("dbo.StaffInterventionGroup", new[] { "InterventionGroupId" });
            DropIndex("dbo.StaffInterventionGroup", new[] { "StaffID" });
            DropIndex("dbo.InterventionGroup", new[] { "InterventionTypeID" });
            DropIndex("dbo.InterventionGroup", new[] { "SchoolID" });
            DropIndex("dbo.InterventionGroup", new[] { "SchoolStartYear" });
            DropIndex("dbo.InterventionGroup", new[] { "StaffID" });
            DropTable("dbo.StudentInterventionGroup");
            DropTable("dbo.StaffInterventionGroup");
            DropTable("dbo.InterventionGroup");
        }
    }
}

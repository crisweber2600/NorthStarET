namespace NorthStar.EF6.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class districtsettings2 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.StaffSetting", "ModifiedDate", c => c.DateTime());
            AddColumn("dbo.StaffSetting", "Ip", c => c.String());
            AddColumn("dbo.StaffSetting", "ModifiedBy", c => c.String());
        }
        
        public override void Down()
        {
            DropColumn("dbo.StaffSetting", "ModifiedBy");
            DropColumn("dbo.StaffSetting", "Ip");
            DropColumn("dbo.StaffSetting", "ModifiedDate");
        }
    }
}
